package vehicleinsurance.dto;

public class Vehicle {
	int vehicleNumber,insurancePeriod;
	int vehicleType;
	String aadharNumber,mobileNumber;
	public int getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(int vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public int getInsurancePeriod() {
		return insurancePeriod;
	}
	public Vehicle(int vehicleNumber, int insurancePeriodPeriod, int vehicleType, String aadharNumber, String mobileNumber, int insurancePeriod) {
		super();
		this.vehicleNumber = vehicleNumber;
		this.insurancePeriod = insurancePeriod;
		this.vehicleType = vehicleType;
		this.aadharNumber = aadharNumber;
		this.mobileNumber = mobileNumber;
	}
	public Vehicle() {
		// TODO Auto-generated constructor stub
	}
	public Vehicle(int vehicleType2, int insurancePeriod2, String aadharNumber2, String mobileNumber2) {
		this.vehicleType = vehicleType2;
		this.insurancePeriod = insurancePeriod2;
		this.aadharNumber = aadharNumber2;
		this.mobileNumber = mobileNumber2;



	}
	public void setInsurancePeriod(int insurancePeriod) {
		this.insurancePeriod = insurancePeriod;
	}
	public int getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(int vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	

}
