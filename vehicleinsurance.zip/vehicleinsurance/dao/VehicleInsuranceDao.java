package vehicleinsurance.dao;

import java.util.Map;

import vehicleinsurance.dto.Vehicle;

public interface VehicleInsuranceDao {

	boolean registration(Vehicle vehicle);

	Map validityCheck(int vehicleNumber);

}
