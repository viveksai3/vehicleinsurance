package vehicleinsurance.dao;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;


import vehicleinsurance.dto.Vehicle;

public class VehicleInsuranceDaoImpl implements VehicleInsuranceDao {
	Map<Integer,Vehicle> vehicleMap=new HashMap<Integer, Vehicle>();

	public boolean registration(Vehicle vehicle) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");  
		   LocalDateTime now = LocalDateTime.now();  
		//adding key and values to the map
		vehicleMap.put(vehicle.getVehicleNumber(),new Vehicle(vehicle.getVehicleType(),vehicle.getInsurancePeriod(),vehicle.getAadharNumber(),vehicle.getMobileNumber()));
		
		
		
		   
		return true;
	}

	public Map validityCheck(int vehicleNumber) {
		Map<Integer,String> data=new HashMap<Integer, String>();

		for(Map.Entry<Integer,Vehicle> m:vehicleMap.entrySet())
		{
			if(m.getKey()==vehicleNumber)
			{
				//System.out.println("your validity period is :"+m.getValue().getInsurancePeriod());
				Calendar date = Calendar.getInstance();
			    date.setTime(new Date());
			    Format f = new SimpleDateFormat("dd-MMMM-yyyy");
			    
			    date.add(Calendar.YEAR,m.getValue().getInsurancePeriod());
			   // System.out.println("your insurance expires on :"+f.format(date.getTime()));
			    data.put(m.getValue().getInsurancePeriod(), f.format(date.getTime()));
			}
			System.out.println("print:"+data);
			
		}
		return data;
	}

}
