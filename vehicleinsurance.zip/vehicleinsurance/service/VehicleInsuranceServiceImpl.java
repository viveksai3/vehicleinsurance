package vehicleinsurance.service;

import java.util.Map;

import vehicleinsurance.dao.VehicleInsuranceDao;
import vehicleinsurance.dao.VehicleInsuranceDaoImpl;
import vehicleinsurance.dto.Vehicle;

public class VehicleInsuranceServiceImpl implements VehicleInsuranceService {
	VehicleInsuranceDao dao=new VehicleInsuranceDaoImpl();
	public boolean isAadhar(String aadhar) {
		boolean status=false;
		if(aadhar.length()==12)
		{
			status=true;
		}
		return status;
	}

	public boolean isMobile(String mobile) {
		boolean status=false;
		if(mobile.length()==10)
		{
			status=true;
		}
		return status;
	}

	public boolean registration(Vehicle vehicle) {
		
		return dao.registration(vehicle);
	}

	public Map validityCheck(int vehicleNumber) {
		return dao.validityCheck(vehicleNumber);
		
	}

}
