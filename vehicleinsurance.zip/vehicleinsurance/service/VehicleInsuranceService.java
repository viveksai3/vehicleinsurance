package vehicleinsurance.service;

import java.util.Map;

import vehicleinsurance.dto.Vehicle;

public interface VehicleInsuranceService {

	boolean registration(Vehicle vehicle);

	Map validityCheck(int vehicleNumber);

}
