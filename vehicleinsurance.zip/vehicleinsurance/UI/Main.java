package vehicleinsurance.UI;

import java.util.Scanner;

import vehicleinsurance.dto.Vehicle;
import vehicleinsurance.service.VehicleInsuranceService;
import vehicleinsurance.service.VehicleInsuranceServiceImpl;

public class Main {
	
	public static void main(String[] args) {
		VehicleInsuranceServiceImpl serviceImpl=new VehicleInsuranceServiceImpl();
		VehicleInsuranceService service=new VehicleInsuranceServiceImpl();
		Vehicle vehicle=new Vehicle();
		Scanner info=new Scanner(System.in);
		while(true)
		{
			abc:
		System.out.println("enter choice :\n1)vehicle insurance registartion\n2)vehicle insurance validity check\n3)exit");
		int ch=info.nextInt();
		switch(ch)
		{
		case 1:
		System.out.println("enter vehicle number");
		vehicle.setVehicleNumber(info.nextInt());
		System.out.println("enter vehicle type(2-wheeler or 4-wheeler");
		vehicle.setVehicleType(info.nextInt());
		System.out.println("enter iinsurance period(in years)");
		vehicle.setInsurancePeriod(info.nextInt());
		System.out.println("enter aadhar number");
		String aadhar=info.next();
		if(serviceImpl.isAadhar(aadhar))
		{
			vehicle.setAadharNumber(aadhar);
		}
		else
		{
			System.out.println("invalid aadhar");
			System.exit(0);
		}
		System.out.println("enter mobile number");
		String mobile=info.next();
		//method which takes to registartion
		if(serviceImpl.isMobile(mobile))
		{
			vehicle.setMobileNumber(mobile);
		}
		if(service.registration(vehicle))
		{
			System.out.println("registartion succssful");
		}
		
		case 2:
			System.out.println("enter vehicle number");
			int vehicleNumber=info.nextInt();
			//validation mehtod
			System.out.println("your validity period and year of expiry are :"+service.validityCheck(vehicleNumber));
		
		case 3:
			System.exit(0);
}
}
}
}